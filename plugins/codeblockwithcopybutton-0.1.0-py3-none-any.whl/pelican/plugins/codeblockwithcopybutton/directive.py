from docutils import nodes
from docutils.parsers.rst import Directive, directives
from pygments import highlight
from pygments.lexers import get_lexer_by_name

from .formatter import HtmlFormatterWithCopyButton

class CodeBlockWithButton(Directive):
    required_arguments = 1
    optional_arguments = 0
    has_content = True

    def run(self):
        language = self.arguments[0] or "python"
        code = '\n'.join(self.content)
        lexer = get_lexer_by_name(language)
        formatter = HtmlFormatterWithCopyButton(language=language)
        highlighted_code = highlight(code, lexer, formatter)
        code_block = nodes.raw('', highlighted_code, format="html")
        return [code_block]

def register():
    """Override `code` directive"""
    directives.register_directive("code", CodeBlockWithButton)
