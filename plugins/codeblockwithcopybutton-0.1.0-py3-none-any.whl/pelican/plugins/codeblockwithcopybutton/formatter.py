from pygments.formatters.html import HtmlFormatter

class HtmlFormatterWithCopyButton(HtmlFormatter):
    """A custom HtmlFormatter that adds a `Copy` button to the generated HTML."""

    def __init__(self, *args, **kwargs):
        self.language = kwargs.pop('language', 'python')
        super().__init__(*args, **kwargs)
    
    def wrap(self, source):
        yield 0, f"""<div class='code {self.language} literal-block'>"""
        yield from super().wrap(source)
        yield 0, """<button class='copy'>Copy</span></div>"""
